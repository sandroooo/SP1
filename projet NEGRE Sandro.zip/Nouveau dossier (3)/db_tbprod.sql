-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 23 Janvier 2018 à 11:39
-- Version du serveur :  5.7.14
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `db_tbprod`
--

-- --------------------------------------------------------

--
-- Structure de la table `agent`
--

CREATE TABLE `agent` (
  `ag_id` int(10) NOT NULL,
  `ag_nom` varchar(30) NOT NULL,
  `ag_dateNaissance` date NOT NULL,
  `ag_login` varchar(80) NOT NULL,
  `ag_mdp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `agent`
--

INSERT INTO `agent` (`ag_id`, `ag_nom`, `ag_dateNaissance`, `ag_login`, `ag_mdp`) VALUES
(1, 'GENE', '1966-01-01', 'gene', 'sammy'),
(2, 'PAULO', '1966-01-01', 'paulo', 'max');

-- --------------------------------------------------------

--
-- Structure de la table `beneficie`
--

CREATE TABLE `beneficie` (
  `spr_id` int(10) NOT NULL,
  `et_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `beneficie`
--

INSERT INTO `beneficie` (`spr_id`, `et_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(8, 2),
(9, 1),
(9, 2),
(10, 1),
(10, 2),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(18, 2);

-- --------------------------------------------------------

--
-- Structure de la table `consolidation`
--

CREATE TABLE `consolidation` (
  `cons_id` int(10) NOT NULL,
  `cons_nom` varchar(100) DEFAULT NULL,
  `tcons_id` int(10) DEFAULT NULL,
  `pr_id` int(10) DEFAULT NULL,
  `tb_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `consolidation`
--

INSERT INTO `consolidation` (`cons_id`, `cons_nom`, `tcons_id`, `pr_id`, `tb_id`) VALUES
(1, 'Matérialité\r\n', 1, 1, 1),
(2, 'Suivi Medico Administratif', 1, 1, 1),
(3, 'DIADEME', 1, 2, 1),
(7, 'Traitement des DSIJ', 1, 2, 1),
(10, 'Traitement échéancier Progrès', 1, 2, 1),
(11, 'Rente', 1, 3, 1),
(13, 'Réclamations', 1, 4, 1),
(14, 'Courriers expédiés/DIADEME', 1, 5, 1);

-- --------------------------------------------------------

--
-- Structure de la table `date`
--

CREATE TABLE `date` (
  `date_id` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `date`
--

INSERT INTO `date` (`date_id`) VALUES
('2018-01-19');

-- --------------------------------------------------------

--
-- Structure de la table `dispose`
--

CREATE TABLE `dispose` (
  `prf_id` int(10) NOT NULL,
  `ag_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `dispose`
--

INSERT INTO `dispose` (`prf_id`, `ag_id`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Structure de la table `etat`
--

CREATE TABLE `etat` (
  `et_id` int(10) NOT NULL,
  `et_libelle` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `etat`
--

INSERT INTO `etat` (`et_id`, `et_libelle`) VALUES
(1, 'traités'),
(2, 'Retours'),
(3, 'dont Invalidés'),
(4, 'Traitement automatique'),
(5, 'Traitement manuel'),
(6, 'Courriers expédiés');

-- --------------------------------------------------------

--
-- Structure de la table `permet`
--

CREATE TABLE `permet` (
  `tb_id` int(10) NOT NULL,
  `prf_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `permet`
--

INSERT INTO `permet` (`tb_id`, `prf_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `processus`
--

CREATE TABLE `processus` (
  `pr_id` int(10) NOT NULL,
  `pr_nom` varchar(100) NOT NULL,
  `tb_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `processus`
--

INSERT INTO `processus` (`pr_id`, `pr_nom`, `tb_id`) VALUES
(1, 'MATERIALITE / SUIVI MEDICO ADMINISTRATIF', 1),
(2, 'PRESTATIONS EN ESPECE', 1),
(3, 'RENTE', 1),
(4, 'RELATION CLIENTS', 1),
(5, 'AUTRES ACTIVITES', 1);

-- --------------------------------------------------------

--
-- Structure de la table `profil`
--

CREATE TABLE `profil` (
  `prf_id` int(10) NOT NULL,
  `prf_libelle` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `profil`
--

INSERT INTO `profil` (`prf_id`, `prf_libelle`) VALUES
(1, 'agent_ATMP'),
(2, 'cadre_ATMP'),
(3, 'statisticien_ATMP');

-- --------------------------------------------------------

--
-- Structure de la table `sousprocessus`
--

CREATE TABLE `sousprocessus` (
  `spr_id` int(10) NOT NULL,
  `spr_nom` varchar(100) NOT NULL,
  `pr_id` int(10) DEFAULT NULL,
  `cons_id` int(10) DEFAULT NULL,
  `sprnext_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sousprocessus`
--

INSERT INTO `sousprocessus` (`spr_id`, `spr_nom`, `pr_id`, `cons_id`, `sprnext_id`) VALUES
(1, 'DAT-IDAT (travail, trajet)', 1, 1, NULL),
(2, 'initial', 1, 1, NULL),
(3, 'prolongation', 1, 1, NULL),
(4, 'final', 1, 1, NULL),
(5, 'rechute', 1, 1, NULL),
(6, 'ICM', 1, 1, NULL),
(7, 'LM2A', 1, 1, NULL),
(8, 'Courrier questionnaire demande Avis SM', 1, 1, NULL),
(9, 'Transfert Mutation', 1, 1, NULL),
(10, 'Cures', 1, 1, NULL),
(11, 'Avis d\'admission', 1, 1, NULL),
(12, 'Expertises', 1, 1, NULL),
(13, 'CRA', 1, 1, NULL),
(14, 'Maladie Professionnelle', 1, 1, NULL),
(15, 'Échéances vertes', 1, 1, NULL),
(16, 'Échéance rouges', 1, 1, NULL),
(17, 'Rejets injecteur', 1, 1, NULL),
(18, 'Colloque AT', 1, 2, NULL),
(19, 'Colloque MP', 1, 2, NULL),
(20, 'Attestation Assuré', 2, 3, NULL),
(21, 'Attestation Employeurs', 2, 3, NULL),
(22, 'ITI', 2, NULL, NULL),
(23, 'Régularisations', 2, NULL, NULL),
(24, 'Notifications d\'indus', 2, NULL, NULL),
(25, 'Attestations Assurés', 2, 7, NULL),
(26, 'Attestations Employeurs', 2, 7, NULL),
(27, 'Rejets', 2, NULL, NULL),
(28, 'Compte rendu DSIJ', 2, NULL, NULL),
(29, 'Auto', 2, 10, NULL),
(30, 'Rejets', 2, 10, NULL),
(31, 'Liquidées (révision et attribution)', 3, 11, NULL),
(32, 'TCI', 3, 11, NULL),
(33, 'Échéance Eurydice', 3, 11, NULL),
(34, 'Divers (rachats, transferts)', 3, 11, NULL),
(35, 'Prorata décès liquidés', 3, 11, NULL),
(36, 'Notifications d\'indus', 3, NULL, NULL),
(37, 'Médialog', 4, 13, NULL),
(38, 'Eptica', 4, 13, NULL),
(39, 'Diadème AT_réclamation', 4, 13, NULL),
(40, 'Mail outlook (demandes institutionnelles, Accueils)', 4, 13, NULL),
(41, 'Téléphone', 4, 13, NULL),
(42, 'Plis simples', 5, 14, NULL),
(43, 'Plis recommandés', 5, 14, NULL),
(44, 'Indexation DIADEME', 5, 14, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `tableaubord`
--

CREATE TABLE `tableaubord` (
  `tb_id` int(10) NOT NULL,
  `tb_titre` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tableaubord`
--

INSERT INTO `tableaubord` (`tb_id`, `tb_titre`) VALUES
(1, 'Fiche Prod Agents ATMP');

-- --------------------------------------------------------

--
-- Structure de la table `typeconsolidation`
--

CREATE TABLE `typeconsolidation` (
  `tcons_id` int(10) NOT NULL,
  `tcons_libelle` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `typeconsolidation`
--

INSERT INTO `typeconsolidation` (`tcons_id`, `tcons_libelle`) VALUES
(1, 'cumul'),
(2, 'taux');

-- --------------------------------------------------------

--
-- Structure de la table `valeursousprocessus`
--

CREATE TABLE `valeursousprocessus` (
  `ag_id` int(10) NOT NULL,
  `tb_id` int(10) NOT NULL,
  `date_id` date NOT NULL,
  `spr_id` int(10) NOT NULL,
  `et_id` int(10) NOT NULL,
  `val_valeur` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `valeursousprocessus`
--

INSERT INTO `valeursousprocessus` (`ag_id`, `tb_id`, `date_id`, `spr_id`, `et_id`, `val_valeur`) VALUES
(1, 1, '2018-01-19', 1, 1, 20),
(1, 1, '2018-01-19', 1, 2, 7),
(1, 1, '2018-01-19', 2, 1, 4),
(1, 1, '2018-01-19', 2, 2, NULL),
(1, 1, '2018-01-19', 3, 1, NULL),
(1, 1, '2018-01-19', 3, 2, NULL),
(1, 1, '2018-01-19', 4, 1, 18),
(1, 1, '2018-01-19', 4, 2, NULL),
(1, 1, '2018-01-19', 5, 1, NULL),
(1, 1, '2018-01-19', 5, 2, NULL),
(1, 1, '2018-01-19', 6, 1, NULL),
(1, 1, '2018-01-19', 6, 2, 6),
(1, 1, '2018-01-19', 7, 1, 8),
(1, 1, '2018-01-19', 7, 2, NULL),
(1, 1, '2018-01-19', 8, 1, NULL),
(1, 1, '2018-01-19', 8, 2, NULL),
(1, 1, '2018-01-19', 9, 1, 9),
(1, 1, '2018-01-19', 9, 2, NULL),
(1, 1, '2018-01-19', 10, 1, NULL),
(1, 1, '2018-01-19', 10, 2, NULL),
(1, 1, '2018-01-19', 11, 1, NULL),
(1, 1, '2018-01-19', 11, 2, NULL),
(1, 1, '2018-01-19', 12, 1, NULL),
(1, 1, '2018-01-19', 12, 2, NULL),
(1, 1, '2018-01-19', 13, 1, NULL),
(1, 1, '2018-01-19', 13, 2, NULL),
(1, 1, '2018-01-19', 14, 1, NULL),
(1, 1, '2018-01-19', 14, 2, NULL),
(1, 1, '2018-01-19', 15, 1, 4),
(1, 1, '2018-01-19', 15, 2, NULL),
(1, 1, '2018-01-19', 16, 1, NULL),
(1, 1, '2018-01-19', 16, 2, NULL),
(1, 1, '2018-01-19', 17, 1, NULL),
(1, 1, '2018-01-19', 17, 2, 10),
(1, 1, '2018-01-19', 18, 1, 20),
(1, 1, '2018-01-19', 19, 1, 5),
(1, 1, '2018-01-19', 20, 1, NULL),
(1, 1, '2018-01-19', 20, 2, NULL),
(1, 1, '2018-01-19', 20, 3, NULL),
(1, 1, '2018-01-19', 21, 1, NULL),
(1, 1, '2018-01-19', 21, 2, NULL),
(1, 1, '2018-01-19', 21, 3, NULL),
(1, 1, '2018-01-19', 22, 1, NULL),
(1, 1, '2018-01-19', 22, 2, NULL),
(1, 1, '2018-01-19', 22, 3, NULL),
(1, 1, '2018-01-19', 23, 1, NULL),
(1, 1, '2018-01-19', 24, 1, NULL),
(1, 1, '2018-01-19', 25, 4, NULL),
(1, 1, '2018-01-19', 25, 5, NULL),
(1, 1, '2018-01-19', 26, 4, NULL),
(1, 1, '2018-01-19', 26, 5, NULL),
(1, 1, '2018-01-19', 27, 4, NULL),
(1, 1, '2018-01-19', 27, 5, NULL),
(1, 1, '2018-01-19', 28, 4, NULL),
(1, 1, '2018-01-19', 28, 5, NULL),
(1, 1, '2018-01-19', 29, 1, 2),
(1, 1, '2018-01-19', 30, 1, NULL),
(1, 1, '2018-01-19', 31, 1, NULL),
(1, 1, '2018-01-19', 32, 1, NULL),
(1, 1, '2018-01-19', 33, 1, NULL),
(1, 1, '2018-01-19', 34, 1, NULL),
(1, 1, '2018-01-19', 35, 1, NULL),
(1, 1, '2018-01-19', 36, 1, NULL),
(1, 1, '2018-01-19', 37, 1, NULL),
(1, 1, '2018-01-19', 38, 1, NULL),
(1, 1, '2018-01-19', 39, 1, NULL),
(1, 1, '2018-01-19', 40, 1, NULL),
(1, 1, '2018-01-19', 41, 1, NULL),
(1, 1, '2018-01-19', 42, 6, 2),
(1, 1, '2018-01-19', 43, 6, NULL),
(1, 1, '2018-01-19', 44, 6, NULL);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`ag_id`);

--
-- Index pour la table `beneficie`
--
ALTER TABLE `beneficie`
  ADD PRIMARY KEY (`spr_id`,`et_id`),
  ADD KEY `spr_id` (`spr_id`,`et_id`);

--
-- Index pour la table `consolidation`
--
ALTER TABLE `consolidation`
  ADD PRIMARY KEY (`cons_id`),
  ADD KEY `consolidation_fk1` (`tcons_id`),
  ADD KEY `consolidation_fk2` (`pr_id`),
  ADD KEY `consolidation_fk3` (`tb_id`);

--
-- Index pour la table `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`date_id`);

--
-- Index pour la table `dispose`
--
ALTER TABLE `dispose`
  ADD PRIMARY KEY (`prf_id`,`ag_id`),
  ADD KEY `dispose_fk1` (`prf_id`),
  ADD KEY `dispose_fk2` (`ag_id`);

--
-- Index pour la table `etat`
--
ALTER TABLE `etat`
  ADD PRIMARY KEY (`et_id`);

--
-- Index pour la table `permet`
--
ALTER TABLE `permet`
  ADD PRIMARY KEY (`tb_id`,`prf_id`),
  ADD KEY `dispose_fk1` (`tb_id`),
  ADD KEY `dispose_fk2` (`prf_id`);

--
-- Index pour la table `processus`
--
ALTER TABLE `processus`
  ADD PRIMARY KEY (`pr_id`),
  ADD KEY `processus_fk1` (`tb_id`);

--
-- Index pour la table `profil`
--
ALTER TABLE `profil`
  ADD PRIMARY KEY (`prf_id`);

--
-- Index pour la table `sousprocessus`
--
ALTER TABLE `sousprocessus`
  ADD PRIMARY KEY (`spr_id`),
  ADD KEY `sousProcessus_fk1` (`pr_id`),
  ADD KEY `sousProcessus_fk2` (`cons_id`),
  ADD KEY `sousProcessus_fk3` (`sprnext_id`);

--
-- Index pour la table `tableaubord`
--
ALTER TABLE `tableaubord`
  ADD PRIMARY KEY (`tb_id`);

--
-- Index pour la table `typeconsolidation`
--
ALTER TABLE `typeconsolidation`
  ADD PRIMARY KEY (`tcons_id`);

--
-- Index pour la table `valeursousprocessus`
--
ALTER TABLE `valeursousprocessus`
  ADD PRIMARY KEY (`ag_id`,`tb_id`,`spr_id`,`et_id`),
  ADD KEY `valeurSousProcessus_fk1` (`ag_id`),
  ADD KEY `valeurSousProcessus_fk3` (`tb_id`),
  ADD KEY `valeurSousProcessus_fk4` (`spr_id`),
  ADD KEY `valeurSousProcessus_fk5` (`et_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `agent`
--
ALTER TABLE `agent`
  MODIFY `ag_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `consolidation`
--
ALTER TABLE `consolidation`
  MODIFY `cons_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `etat`
--
ALTER TABLE `etat`
  MODIFY `et_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `processus`
--
ALTER TABLE `processus`
  MODIFY `pr_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `profil`
--
ALTER TABLE `profil`
  MODIFY `prf_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `sousprocessus`
--
ALTER TABLE `sousprocessus`
  MODIFY `spr_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT pour la table `tableaubord`
--
ALTER TABLE `tableaubord`
  MODIFY `tb_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `typeconsolidation`
--
ALTER TABLE `typeconsolidation`
  MODIFY `tcons_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
