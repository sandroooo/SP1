<html>
 <head>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style3.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
  </head>
  <body>
	
	<?php
  
		try
			{
				$bdd = new PDO('mysql:host=localhost;dbname=db_tbprod;charset=utf8', 'root', '');
			}
		catch (Exception $e)
			{
				die('Erreur : ' . $e->getMessage());
			}
	?>
	
	<?php 
		/*Selection de l'Agent */
		$reponse = $bdd->query("SELECT * FROM `agent` WHERE ag_login = 'gene' AND ag_mdp ='sammy'");
		$reponse2 = $bdd->query("SELECT * FROM `tableaubord` WHERE tb_id = 1 ");
		
		
	
		$donnees = $reponse->fetch();
		$donnees2 = $reponse2->fetch();
				
		$nomAgt = $donnees['ag_nom'];
		$idAgt = $donnees['ag_id']; 
		$dateJ= '2018-01-19';
		$titreTb = $donnees2['tb_titre'];
		$idTb = $donnees2['tb_id'];
	?>
	
	<div class="container">
		<div class="row">
		
			<!--<div class="col-md-12" id="contour"> -->
			
				<div class="col-md-4"><img class="img-responsive" src="images/cgss.gif" id="cgss"></div>
				<div class="col-md-8"><strong><h1><?php echo $titreTb ?></h1></strong></div>
				<div class="col-md-8" id="info"><strong>Agents n° :</strong> <?php echo $idAgt ?> <strong> &nbsp;&nbsp;  Nom : </strong> <?php echo $nomAgt ?> <strong> &nbsp;&nbsp;&nbsp;&nbsp;  Date : </strong> <?php echo $dateJ ?> </div>
				
				
				
				<div class="row">
				
					<div class="col-md-12" id="tableau">
					<form action="cible.php" method="post">
					<?php $reponse3 = $bdd->query("SELECT `pr_id`,`pr_nom` FROM `processus` WHERE tb_id = ".$idTb." ORDER BY `pr_id`");
	

				while ($donnees3 = $reponse3->fetch())
					{
						$nomProcess = $donnees3['pr_nom'];
						$idProcess = $donnees3['pr_id']; 
					
					 
					
					?>	
					<div class="row">
						<div class="col-md-12">
							<div id="accordion">
								<div class="card" id="presta">
								  <div class="card-header">
									<a class="card-link" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $idProcess ?>">
									  <h3><?php echo $nomProcess ?>&nbsp; ▼</h3>
									</a>
								  </div>
								  <div id="collapse<?php echo $idProcess ?>" class="collapse show">
								  
								  <?php $reponse4 = $bdd->query("SELECT `cons_id`,`cons_nom` FROM `consolidation` WHERE `pr_id` = ".$idProcess.""); 
								  
									/*if ($reponse4->fetch() == true)*/
									if ($reponse4)
										{
											/* Sous Processus Consolidés */
											while ($donnees4 = $reponse4->fetch())
												{
													$idConso = $donnees4['cons_id']; 
													$nomConso = $donnees4['cons_nom'];
													?>
													</br>
													<?php
													$reponse5 = $bdd->query("SELECT `spr_id`,`spr_nom` FROM `sousprocessus` WHERE `cons_id` = ".$idConso." AND `pr_id`=".$idProcess." " );
													while ($donnees5 = $reponse5->fetch())
														{	
															$recursif=true;
															$idSProcess = $donnees5['spr_id'];
															$nomSProcess = $donnees5['spr_nom'];
															
															while ($recursif)
															{
																$reponse6 = $bdd->query("SELECT * FROM `sousprocessus` WHERE `spr_id`=".$idSProcess." AND `sprnext_id` IS NULL " );
																
																if ($reponse6)
																	{
																		?>
																		<div class="card-body">	
																			<div class="row">
																				<div class="col-md-4">
																					<div class="row">
																						&nbsp;
																					</div>																			
																					<div class="row">
																						<?php echo $nomSProcess?> :
																					</div>
																					<div class="row">
																						&nbsp;
																					</div>
																				</div>
																		<?php $reponse7 = $bdd->query("SELECT e.et_libelle, val_valeur FROM `valeursousprocessus` v 
																									INNER JOIN etat e ON v.et_id = e.et_id
																									WHERE v.`ag_id` =".$idAgt."
																									AND v.date_id ='".$dateJ."'
																									AND v.tb_id=".$idTb."
																									AND v.spr_id =".$idSProcess."");
																		
																									
																		while ($donnees7 = $reponse7->fetch())
																		{
																			$libEtat = $donnees7['et_libelle'];
																			$valeur = $donnees7['val_valeur'];
																		
																			
																		?>
																				
																				<div class="col-md-1">
																				
																					<div class="row">
																						<?php echo $libEtat;?> : 
																					</div>																		
																					<div class="row">
																						
																						<input type="text" class="form-control" id="Formu" readonly value="<?php echo $valeur ?>">
																					</div>
																					</br>
																				</div>
																			
																		<?php	
																		
																		}
																		?>
																			</div>	
																		</div>
														<?php 	
																		$recursif = false ;
																	}
																else
																	{
																		$recursif=true ;
																		$idSProcess = $donnees6['sprnext_id'];
																		
																	}
															}
														} ?>
													
													<div class="row">
														<div class="col-md-4">
															<div class="row">
																&nbsp;
															</div>																			
															<div class="row">
																 TOTAL :
															</div>
															<div class="row">
																&nbsp;
															</div>
														</div>
														<?php $reponse8 = $bdd->query("SELECT e.et_libelle,SUM(val_valeur) AS total FROM `valeursousprocessus` v 
																									INNER JOIN etat e ON v.et_id = e.et_id
																									INNER JOIN sousprocessus s ON v.spr_id = s.spr_id
																									WHERE v.`ag_id` =".$idAgt."
																									AND v.date_id ='".$dateJ."'
																									AND v.tb_id=".$idTb."
																									AND s.cons_id=".$idConso."
																									GROUP BY e.et_libelle");
																					
														while ($donnees8 = $reponse8->fetch())
														{
															$libEtat = $donnees8['et_libelle'];
															$total = $donnees8['total'];
															
														?>
																
															<div class="col-md-1">
															
																<div class="row">
																	<?php echo $libEtat ?> : 
																</div>																		
																<div class="row">
																	<input type="text" class="form-control" id="Formu" readonly value="<?php echo $total ?>">
																</div>
																</br>
															</div>
															
														<?php															
														}
														?>
													</div>
												<?php	
												}
										}
										
									$reponse5 = $bdd->query("SELECT `spr_id`,`spr_nom` FROM `sousprocessus` WHERE `cons_id` IS NULL AND `pr_id`=".$idProcess."" ); 
								  
									if ($reponse5)
										{
											/* Sous Processus non Consolidés */
											while ($donnees5 = $reponse5->fetch())
												{
													$idSProcess = $donnees5['spr_id'];
													
													$reponse5 = $bdd->query("SELECT `spr_id`,`spr_nom` FROM `sousprocessus` WHERE `spr_id` = ".$idSProcess."" );
													while ($donnees5 = $reponse5->fetch())
														{	
															$recursif=true;
															$idSProcess = $donnees5['spr_id'];
															$nomSProcess = $donnees5['spr_nom'];
															
															while ($recursif)
															{
																$reponse6 = $bdd->query("SELECT * FROM `sousprocessus` WHERE `spr_id`=".$idSProcess." AND `sprnext_id` IS NULL " );
																
																if ($reponse6)
																	{
									?>
																		<div class="card-body">	
																			<div class="row">
																			
																				<div class="col-md-4">
																					<div class="row">
																						&nbsp;
																					</div>																			
																					<div class="row">
																						<?php echo $nomSProcess?> :
																					</div>
																					<div class="row">
																						&nbsp;
																					</div>
																				</div>
																		<?php $reponse7 = $bdd->query("SELECT e.et_libelle, val_valeur FROM `valeursousprocessus` v 
																									INNER JOIN etat e ON v.et_id = e.et_id
																									WHERE v.`ag_id` =".$idAgt."
																									AND v.date_id ='".$dateJ."'
																									AND v.tb_id=".$idTb."
																									AND v.spr_id =".$idSProcess."");
																									
																		while ($donnees7 = $reponse7->fetch())
																		{
																			$libEtat = $donnees7['et_libelle'];
																			$valeur = $donnees7['val_valeur'];
																			
																		?>
																				
																				<div class="col-md-1">
																				
																					<div class="row">
																						<?php echo $libEtat ?> : 
																					</div>																		
																					<div class="row">
																						<input type="text" class="form-control" id="Formu" readonly value="<?php echo $valeur ?>">
																					</div>
																					
																				</div>
																			
																		<?php															
																		}
																		?>
																			</div>	
																		</div>
														<?php 	
																		$recursif = false ;
																	}
																else
																	{
																		$recursif=true ;
																		$idSProcess = $donnees6['sprnext_id'];
																		
																	}
															}
														}	
												}
										}
										
													?>
								  </div>
								</div>
							</div>
						</div>
					</div>
					<?php
					}
					?>
									
					<div class="row">
						<div class="col-md-12" ><button type="submit" value="Valider" class="btn btn-default" id ="buttonVal">Valider</button></div>
					</div>
					</form>	
					</div>
					
				</div>
			
			<!--</div>-->
		</div>
	</div>
</html>